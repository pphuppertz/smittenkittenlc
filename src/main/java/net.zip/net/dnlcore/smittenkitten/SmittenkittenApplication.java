package net.dnlcore.smittenkitten;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmittenkittenApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmittenkittenApplication.class, args);
	}

}
